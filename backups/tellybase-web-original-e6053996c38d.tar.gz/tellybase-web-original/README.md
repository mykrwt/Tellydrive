# TellyDrive

A complete private cloud storage and credentials experience for Next.js 16 with a private Telegram chat acting as the production storage & account database.

## Features

- Sign up, sign in, remember-me sessions, protected dashboard, and sign out
- Passwords hashed with Node.js `scrypt` and unique salts (plaintext is never stored)
- Signed, HTTP-only, SameSite session cookies
- Versioned JSON account database uploaded to Telegram
- Responsive dark UI with loading, validation, error, and connection states
- Local JSON fallback during development so the flow can be tested immediately

### Storage sections

- **Gallery** (`/dashboard`) — photos and videos only, with a Google Photos–style
  browsing experience: day-grouped grid ("Today", "Yesterday", dates), hover
  selection, lightbox viewer, search, filters, chunked uploads up to 2 GB.
- **Files** (`/dashboard/files`) — a full-featured cloud file manager with folders and
  subfolders: create/rename/move/delete folders, upload files into any folder,
  category filtering (Documents, Media, Audio, Archives), move/rename/delete files,
  breadcrumb navigation, grid & list views, previews for images/videos/audio/docs,
  and downloads.
- **Admin** (`/dashboard/admin`) — administrator-only page with upload &
  file management, instance statistics (users, files, folders, storage),
  a user table with role management, and reserved slots for future admin tools.

### Admin accounts

An account is an admin when its stored `role` is `"admin"` (promotable from the
Admin page) **or** its email is listed in `ADMIN_EMAILS` (comma-separated,
case-insensitive). To bootstrap the **first** admin (no admin exists yet to do
the promoting):

1. **CLI, takes effect immediately (no redeploy):**
   ```bash
   node scripts/set-admin.mjs you@example.com
   # or: npm run make-admin -- you@example.com  (use --demote to revoke)
   ```
   Run it from the repo root with `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` in
   the environment or in `.env` / `.env.local`. It edits the role directly in
   the Telegram-backed database (or the local `.data/auth.json` dev fallback
   when those vars are unset).
2. **Env var:** set `ADMIN_EMAILS=you@example.com` (comma-separated list works),
   then redeploy/restart. The account keeps admin rights only while its email
   stays in the list.

Afterwards the **Admin** section appears in the dashboard navigation
(`/dashboard/admin`) — no re-login needed.

## Run locally

```bash
npm install
npm run dev
```

Open <http://localhost:3000>. Without Telegram variables, development uses `.data/auth.json` automatically.

## Connect Telegram for production

1. Create a bot with [@BotFather](https://t.me/BotFather) and copy its token.
2. Create a **private channel or supergroup dedicated to TellyDrive** (basic groups are not supported).
3. Add the bot as an administrator with permission to:
   - **Post Messages** (to upload database revisions)
   - **Edit Chat Info** ("Change Channel Info" / "Change Group Info", so the bot can update the `TBAUTH:<file_id>` pointer in the description)
4. Obtain the numeric chat id (channel and supergroup ids start with `-100`, e.g., `-1001234567890`).
5. In Vercel or your `.env` file, add:

```env
TELEGRAM_BOT_TOKEN=123456:your_bot_token
TELEGRAM_CHAT_ID=-1001234567890
SESSION_SECRET=optional_random_32_byte_secret
```

`SESSION_SECRET` is recommended; if absent, the server derives session signatures from the bot token. Never prefix Telegram variables with `NEXT_PUBLIC_`. Do not wrap values in quotes or include a `bot` prefix in `TELEGRAM_BOT_TOKEN`.

The app uploads `tellydrive-auth-rN.json` to the private chat and saves the latest Telegram `file_id` in the chat description as `TBAUTH:<file_id>`.

## Troubleshooting Telegram setup

- **Bad Request: chat not found**: Ensure `TELEGRAM_CHAT_ID` includes the `-100` prefix for supergroups/channels, and verify the bot was added to the chat.
- **Bad Request: not enough rights to change chat info**: Edit the bot's admin permissions in Telegram and enable "Change Channel Info" or "Change Group Info".
- **Unauthorized**: Re-check `TELEGRAM_BOT_TOKEN`.
- **Method is available only for supergroups and channels**: Convert your group into a supergroup or create a private channel.

## Verify

```bash
npm run lint
npm run build
```

## Security notes

Telegram credentials stay in server-only modules. The stored database contains profile fields, timestamps, password salts, and scrypt hashes—never plaintext passwords. For a high-risk production system, add distributed rate limiting, email verification, password recovery, and MFA or use a dedicated authentication provider.
